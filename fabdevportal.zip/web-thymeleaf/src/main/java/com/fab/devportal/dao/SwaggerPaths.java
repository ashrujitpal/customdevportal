package com.fab.devportal.dao;

import java.util.List;

public class SwaggerPaths {
	
	private List<SwaggerPath> paths;

	public List<SwaggerPath> getPaths() {
		return paths;
	}

	public void setPaths(List<SwaggerPath> paths) {
		this.paths = paths;
	}

	
	
}
